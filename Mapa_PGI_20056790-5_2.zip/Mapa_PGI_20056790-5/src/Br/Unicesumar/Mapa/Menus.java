package Br.Unicesumar.Mapa;

public class Menus {

    private int opcao;



    public void menuP(){
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                        "            MENU PRINCIPAL");
        System.out.println("\n[1] - CADASTRO DE PRODUTOS.");
        System.out.println("[2] - MOVIMENTAÇÃO.");
        System.out.println("[3] - REAJUSTE DE PREÇOS.");
        System.out.println("[4] - RELATÓRIOS.");
        System.out.println("[0] - FINALIZAR.");
        System.out.println("OPÇÃO: ");
    }

    public void menuI(){
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "         CADASTRO DE PRODUTOS");
        System.out.println("\n[1] - INCLUSÃO.");
        System.out.println("[2] - ALTERAÇÃO.");
        System.out.println("[3] - CONSULTA.");
        System.out.println("[4] - EXCLUSÃO.");
        System.out.println("[0] - RETORNAR.");
        System.out.println("OPÇÃO: ");
    }

    public void menuM(){
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "             MOVIMENTAÇÃO");
        System.out.println("\n[1] - ENTRADA.");
        System.out.println("[2] - SAIDA.");
        System.out.println("[0] - RETORNAR.");
        System.out.println("OPÇÃO: ");
    }





    public int getpcao() {
        return opcao;
    }

    public void setpcao(int opcao) {
        this.opcao = opcao;
    }
}
