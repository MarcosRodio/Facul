package Br.Unicesumar.Mapa;

public class Produto {

    private String nome;
    private int qtde;
    private double valor;
    private String medida;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

    public double getvalor() {
        return valor;
    }

    public void setPreco(double preco) {
        this.valor = preco;
    }

    public String getMedida() {
        return medida;
    }

    public void setMedida(String medida) {
        this.medida = medida;
    }
}
