package Br.Unicesumar.Mapa;

import java.util.ArrayList;
import java.util.Scanner;

public class Empresa {

    ArrayList<Produto> centroCusto = new ArrayList<Produto>();


    //imprime Relatório
    void impressao(String nome) {
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            IMPRESSÃO\n");
        for (Produto prod : centroCusto) {
            if (prod.getNome().equalsIgnoreCase(nome)) {
                System.out.println("NOME: " + prod.getNome() + ". " + "PREÇO: R$ " + prod.getvalor() + ". "
                        + "QUANTIDADE: " + prod.getQtde());
            }
        }
    }

    void impressao() {
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            IMPRESSÃO\n");
        for (Produto prod : centroCusto) {
            System.out.println("NOME: " + prod.getNome() + ". " + "PREÇO: R$ " + prod.getvalor() + ". "
                    + "QUANTIDADE: " + prod.getQtde());
        }
    }

    //validações
    private boolean temNome(String nome) {
        Boolean encontrado = false;
        for (Produto item : centroCusto) {
            if (item.getNome().equalsIgnoreCase(nome)) encontrado = true;
        }
        return encontrado;
    }

    private boolean temPreco(double preco) {
        Boolean valor = false;
        if (preco > 0) valor = true;
        return valor;
    }

    private boolean temQtde(int qtde) {
        Boolean quantidade = false;
        if (qtde > 0) quantidade = true;
        return quantidade;
    }

    //Adiciona os itens ao estoque e chama os metodos de validação
    public void Inclusao() {
        double valor;
        int quantidade;
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            INCLUSÃO");
        System.out.print("NOME PRODUTO: ");
        Scanner entrada = new Scanner(System.in);
        String nome = entrada.nextLine();
        if (temNome(nome)) {
            System.out.println("\nJÁ CADASTRADO\n");
        } else {
            do {
                System.out.print("VALOR PRODUTO: ");
                valor = entrada.nextDouble();
                if (valor <= 0) System.out.println("VALOR MENOR QUE 0.");
            } while (!temPreco(valor));
            do {
                System.out.print("QUANTIDADE: ");
                quantidade = entrada.nextInt();
                if (quantidade <= 0) System.out.println("TOTAL PRODUTOS MENOR QUE 0.");
            } while (!temQtde(quantidade));
            System.out.print("MEDIDA: ");
            String medida = entrada.next();
            Produto prod = new Produto();
            Scanner ent = new Scanner(System.in);
            System.out.println("PROSSEGUIR: " + "S/N");
            String continua = ent.next();
            if (continua.equalsIgnoreCase("s"))
                this.centroCusto.add(prod);
            prod.setNome(nome);
            prod.setPreco(valor);
            prod.setQtde(quantidade);
            prod.setMedida(medida);
        }
    }

    //Altera os atributos dos produtos
    public void Alteracao() {
        int qtde = 0;
        double valor = 0;
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            ALTERAÇÃO");

        System.out.println("NOME DO PRODUTO:");
        Scanner entrada = new Scanner(System.in);
        String nome = entrada.nextLine();
        if (temNome(nome)) {
            for (Produto prod : centroCusto) {
                if (prod.getNome().equalsIgnoreCase(nome)) {
                    System.out.println("PRODUTO: " + prod.getNome());
                    System.out.println("QUANTIDADE: " + prod.getQtde() + " "
                            + prod.getMedida() + ".");
                    System.out.println("VALOR: " + prod.getvalor());
                    do {
                        System.out.println("NOVA QUANTIDADE: ");
                        qtde = entrada.nextInt();
                        if (qtde <= 0) System.out.println("VALOR MENOR QUE 0.");
                    } while (!temQtde(qtde));
                    do {
                        System.out.println("NOVO VALOR: ");
                        valor = entrada.nextDouble();
                        if (qtde <= 0) System.out.println("TOTAL PRODUTOS MENOR QUE 0.");
                    } while (!temPreco(valor));
                    System.out.println("NOVA MEDIDA: ");
                    String medida = entrada.next();
                    System.out.println("PROSSEGUIR: " + " S/N");
                    String continua = entrada.next();
                    if (continua.equalsIgnoreCase("s")) {
                        prod.setQtde(qtde);
                        prod.setMedida(medida);
                        prod.setPreco(valor);
                    } else {
                        System.out.println("PROCESSO ABORTADO!!\n");
                    }
                }
            }
        } else {
            System.out.println("NÃO ENCONTRADO!!\n");
        }
    }


    // ALTERA O VALOR DOS ITENS
    public void mudaValor() {
        double valorN = 0;
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            REAJUSTE");
        System.out.println("DIGITE O NOME DO PRODUTO: -> ");
        Scanner entrada = new Scanner(System.in);
        String nome = entrada.nextLine();
        for (Produto produto : centroCusto)
            if (produto.getNome().equalsIgnoreCase(nome)) {
                System.out.println(produto.getNome());
                System.out.println(produto.getQtde());
                System.out.println("NOVO PREÇO: ");
                valorN = entrada.nextDouble();
                double total = valorN;
                System.out.println("PROSSEGUIR: " + "S/N ");
                String continua = entrada.next();
                if (continua.equalsIgnoreCase("s")) produto.setPreco(total);
            } else System.out.println("NÃO ENCONTRADO");
    }

    public void Pesquisa() {
        String continua = "N";
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            PESQUISA");
        do {
            System.out.println("NOME DO PRODUTO: ");
            Scanner entrada = new Scanner(System.in);
            String nome = entrada.nextLine();
            for (Produto produto : centroCusto) {
                if (produto.getNome().equalsIgnoreCase(nome)) {
                    impressao(nome);
                } else System.out.println("NÃO ENCONTRADO");
            }

        } while (continua.equalsIgnoreCase("s")) ;
    }

    private void RemoveItem(String prod) {
        String nome = prod;
        centroCusto.removeIf(item -> item.getNome().equalsIgnoreCase(nome));
    }

    public void Exclusao() {
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            EXCLUSÃO");
            System.out.println("NOME PRODUTO:");
            Scanner entrada = new Scanner(System.in);
            String nome = entrada.nextLine();
            impressao(nome);
            System.out.println("PROSSEGUIR S/N ");
            String continua = entrada.nextLine();
            if (continua.equalsIgnoreCase("s")) RemoveItem(nome);
        }
// menu de movimentação (caixa)
    public void Entrada() {
        int adiciona = 0;
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            ENTRADA");


            System.out.println("INFORME O NOME DO ITEM PARA REGISTRAR A ENTRADA:");

            Scanner entrada = new Scanner(System.in);
            String nome = entrada.nextLine();
            for (Produto item : centroCusto) {
                if (item.getNome().equalsIgnoreCase(nome)) {
                    do {
                        System.out.println(item.getNome());
                        System.out.println(item.getQtde());
                        System.out.println("QUANTIDADE: ");
                        adiciona = entrada.nextInt();
                        if (adiciona <= 0) System.out.println("TOTAL PRODUTOS MENOR QUE 0.");
                    } while (!temQtde(adiciona));
                    int total = item.getQtde() + adiciona;
                    System.out.println("PROSSEGUIR: " + " S/N ");
                    String continua = entrada.next();
                    if (continua.equalsIgnoreCase("s")) item.setQtde(total);
                } else System.out.println("\nPRODUTO NÃO CADASTRADO.");
                break;
            }
        }

    public void saida() {
        int remove = 0;
        System.out.println("\nEMPRESA DE IMPORTAÇÃO DE PRODUTOS LTDA.\n  **SISTEMA DE CONTROLE DE ESTOQUE**\n" +
                "            SAIDA");

            System.out.println("INFORME O NOME DO ITEM PARA REGISTRAR A BAIXA: -> ");
            Scanner entrada = new Scanner(System.in);
            Scanner entrada2 = new Scanner(System.in);
            String nome = entrada.nextLine();
            for (Produto item : centroCusto)

                if (item.getNome().equalsIgnoreCase(nome)) {
                    do {
                        System.out.println(item.getNome());
                        System.out.println(item.getQtde());
                        System.out.println("QUANTIDADE: -> ");
                        remove = entrada2.nextInt();
                        if (remove <= 0) System.out.println("QUANTIDADE INFORMADA DEVE SER MAIOR QUE 0.");
                    } while (!temQtde(remove));
                    int total = item.getQtde() - remove;
                    System.out.println("PROSSEGUIR "  + " S/N");
                    Scanner ler = new Scanner(System.in);
                    String continua = ler.next();
                    if (continua.equalsIgnoreCase("s")) item.setQtde(total);
                    break;
                } else {
                    System.out.println("\nPRODUTO NÃO CADASTRADO");
                }
        }
    }





